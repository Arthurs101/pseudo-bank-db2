// transaction.model.ts
export interface Transaction {
  amount: number;
  date: string; 
  currency: string;
  account_from: string;
  account_to: string;
}
