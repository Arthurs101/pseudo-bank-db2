import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-NotFoundComponent',
  templateUrl: './NotFoundComponent.component.html',
  styleUrls: ['./NotFoundComponent.component.css']
})
export class NotFoundComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
