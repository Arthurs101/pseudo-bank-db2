import { Component } from '@angular/core';

@Component({
  selector: 'app-realizar-transaccion',
  templateUrl: './realizar-transaccion.component.html',
  styleUrls: ['./realizar-transaccion.component.scss']
})
export class RealizarTransaccionComponent {

}
